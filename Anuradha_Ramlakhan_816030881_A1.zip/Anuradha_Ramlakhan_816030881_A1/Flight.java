// Student ID: 816030881

import java.time.LocalDateTime;
public class Flight
{
    private String flightNo;
    private String destinationPoint;
    private String originPoint;
    private LocalDateTime flightDate;
    private LuggageManifest manifest;
    
    public Flight (String flightNo, String destinationPoint, String originPoint, LocalDateTime flightDate)
    {
        flightNo = null;
        destinationPoint = null;
        originPoint = null;
        flightDate = null;
    }
    
    public String checkInLuggage(Passenger p)
    {
        
        return "Invalid Flight";
    }
    
    public String printLuggageManifest()
    {
        return "Luggage Manifest";
    }
    
    public static int getAllowedLuggage(char cabinClass)
    {   
        if(cabinClass == 'F')
        {
            return 3;
        }
        else
            if(cabinClass == 'B')
            {
                return 2;
            }
            else
                if(cabinClass == 'P')
                {
                    return 1;
                }
                else
                    if(cabinClass == 'E')
                    {
                        return 0;
                    }
        
        return -1;
    }
    
    public String toString()
    {
        return "DESTINATION: " 
                + " ORIGIN: ";
    }
}
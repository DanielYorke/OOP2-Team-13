// Student ID: 816030881

public class LuggageSlip
{
    private Passenger owner; //= new Passenger();
    private static int luggageSlipIDCounter = 1;
    private String luggageSlipID;
    private String label;
    
    /*
    public LuggageSlip (Passenger p, Flight f)
    {
        p = new Passenger();
       
        p.passportNumber = null;
        p.firstName = null;
        p.lastName = null;
        p.flightNo = null;
        
        f = new Flight();
        
        f.flightNo = null;
        f.destinationPoint = null;
        f.originPoint = null;
        f.flightDate = null;
        
    }*/
    
    public Passenger getOwner()
    {
        return owner;
    }
    
    public String getLuggageSlipID()
    {
        return luggageSlipID;
    }
    
    private void luggageSlipID()
    {
        if(luggageSlipIDCounter < 5)
        {
            luggageSlipID = "BW600_" /*+ owner.lastName*/ + "_" + luggageSlipIDCounter; 
        }
        
        luggageSlipIDCounter++;
    }
    
    public boolean hasOwner(String passportNumber)
    {
        if(passportNumber != null)
        {
            return true;
        }
        
        return false;
    }
    
    public String toString()
    {
        return luggageSlipID 
                + " PP NO. "   
                + " NAME: " /* + owner.firstName + " " + owner.lastName*/
                + " NUM LUGGAGE: " + luggageSlipID;
    }
}
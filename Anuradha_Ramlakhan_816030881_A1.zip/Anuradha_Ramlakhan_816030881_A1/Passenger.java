// Student ID: 816030881

public class Passenger
{    
    private String passportNumber;
    private String flightNumber;
    private String firstName;
    private String lastName;
    private int numLuggage;
    private char cabinClass;
    
    public Passenger(String passportNumber, String firstName, String lastName, String flightNo)
    {
        passportNumber = null;
        firstName = null;
        lastName = null;
        flightNo = null;
    }
    
    public String getPassportNumber()
    {
        return passportNumber;
    }
    
    public String getflightNumber ()
    {
       return flightNumber; 
    }
    
    public String getFirstName ()
    {
       return firstName; 
    }
    
    public String getLastName ()
    {
       return lastName; 
    }
    
    public int getNumLuggage (){
       return numLuggage; 
    }
    
    public char getCabinClass ()
    {
       return cabinClass; 
    }
    
    public void assignRandomCabinClass()
    {
        int randomNumberGenerated;
        int min = 0;
        int max = 3;
        char classType;
        
        randomNumberGenerated = (int) ((Math.random() * (max - min)) + min);
        
        switch(randomNumberGenerated)
        {
            case 0: System.out.println("F");
            case 1: System.out.println("B");
            case 2: System.out.println("P");
            case 3: System.out.println("E");
        }
        
    }
    
    public String toString()
    {
        return "PASSPORT_NUMBER: " + getPassportNumber()
                + " NAME: " + getFirstName() + " " + getLastName()
                + " NUMBER_OF_LUGGAGE: " + getNumLuggage()
                + " CLASS: ";
                
        //assignRandomCabinClass();
    }
}
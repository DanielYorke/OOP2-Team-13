// Student ID: 816030881
import java.time.LocalDateTime;
import java.util.Random;
import java.io.File;
import java.util.Scanner;

public class LuggageManagementSystem
{
    public static void main(String[] args)
    {
        // provided in assignment1 document
        LocalDateTime d = LocalDateTime.of(2023,1,23,10,00,00);
        Flight yyz = new Flight("BW600", "POS", "YYZ", d);
        
        System.out.println(yyz);
        
        Passenger p;
        int i;
        
        try
        {
            File dataFile = new File ("flights.txt");
            Scanner scanFile = new Scanner(dataFile);
            
            String flightData = "";
            i = 0;
            
            while(scanFile.hasNextLine())
            {
                flightData = scanFile.nextLine();
                System.out.println(flightData);
                
                String[] data = flightData.split(" ");
                String[] ppsInformation = data;
                //String[] data1 = flightData.split(" ");
                String[] firstName = data;
                //String[] data2 = flightData.split(" ");
                String[] lastName = data;
                
                p = new Passenger(ppsInformation[i], firstName[i], lastName[i], "BW600");
                System.out.println(p);
                System.out.println(yyz.checkInLuggageManifest());
                i++;
            }
        }
        catch(Exception e)
        {
            
        }
    }
}
// Student ID: 816030881

import java.util.ArrayList;
public class LuggageManifest
{
    ArrayList <LuggageSlip> luggage = new ArrayList<LuggageSlip>(5);
    
    
    public LuggageManifest()
    {
        Passenger p;
        Flight f;
        for(int i = 0; i < 5; i++)
        {
            luggage.add(new LuggageSlip(p,f));
        }
    }
    
}
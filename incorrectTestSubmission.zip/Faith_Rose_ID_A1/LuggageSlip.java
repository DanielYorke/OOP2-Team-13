//816029963

import java.time.LocalDateTime;
public class LuggageSlip
{
    // instance variables - replace the example below with your own
    public Passenger owner, p;
    public Flight f;
    private int luggageSlipIDCounter;
    private String luggageSlipID;
    private String label;
    
    public Passenger getOwner(){
        return owner;
    }
    
    public int readluggageSlipIDCounter(){
        return luggageSlipIDCounter;
    }
    
    public String getluggageSlipID(){
        return luggageSlipID;
    }
    
        public String getLabel(){
        return label;
    }

    public LuggageSlip(Passenger p, Flight f)
    {
        
        owner=setPassenger(p,owner);
        setFlight(f);
        setPassenger(p);
        luggageSlipIDCounter= 1+luggageSlipIDCounter;
        luggageSlipID = owner.flightNo+"_"+owner.lastName+"_"+luggageSlipIDCounter;
        label=" ";
        // initialise instance variables

    }
    
    public LuggageSlip(Passenger p, Flight f, String label)
    {
        // initialise instance variables
        setPassenger(p);
        setFlight(f);
        owner=setPassenger(p,owner);
        luggageSlipIDCounter= 1+luggageSlipIDCounter;
        luggageSlipID = owner.flightNo+"_"+owner.lastName+"_"+luggageSlipIDCounter;
        setLabel(label);

    }
    
    public Flight setFlight(Flight value)
    {
        f=value;
        return f;
    }
    

    public Passenger setPassenger(Passenger value)
    {
        p= value;
        return p;
    }
    
    public void setLabel(String value)
    {
        if(label!="$105")
        {
            label="$105";
        }
    }
    
    
    public Passenger setPassenger(Passenger p, Passenger owner)
    {
        
        if(p!=owner)
        {
            owner=p;
        }
        return owner;
    }

    
    public boolean hasOwner(String passportNumber)
    {
        // put your code here.
        if(owner.passportNumber==passportNumber)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public String toString()
    {
        // put your code here
        String name= owner.firstName.substring(0,1)+"."+owner.lastName;        
        String format=getluggageSlipID()+" PP NO. "+owner.passportNumber +" NAME: "+name+" NUMLUGGAGE: "+owner.numLuggage+" CLASS: "+owner.cabinClass+" "+getLabel();
        return format;
    }
  
}

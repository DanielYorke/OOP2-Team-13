//816029963

import java.util.ArrayList;
import java.time.LocalDateTime;
import java.util.Iterator;
public class LuggageManifest
{
    // instance variables - replace the example below with your own
    private ArrayList<LuggageSlip> slips;
    public Passenger p;
    public Flight f;
     
    public ArrayList getArraySlips(){
        return slips;
    }

    public LuggageManifest()
    {
        setPassenger(p);
        setFlight(f);
        setSlips();
    }
    
    public Flight setFlight(Flight value)
    {
        f=value;
        return f;
    }
    

    public Passenger setPassenger(Passenger value)
    {
        p= value;
        return p;
    }
    
    public ArrayList<LuggageSlip> setSlips()
    {
        ArrayList<LuggageSlip> slips = new ArrayList<LuggageSlip>(); 
        return slips;
    }
    
   public String addLuggage(Passenger p)
    {
        // put your code here
        String details;
        int allowedPieces=0;//f.getAllowedLuggage(p.cabinClass);
        double excessCost=0;//getExcessLuggageCost(p.numLuggage,allowedPieces);
        //for(int i=0; i<=p.numLuggage; i++) 
        //while()
        //{
                           
           // slips.add(new LuggageSlip(p,f));
        //}
        details="Pieces added: ("+ allowedPieces +"). Excess Cost: $"+excessCost;
        return details;
       // return "Yo";
    }
    
    public double getExcessLuggageCost( int numPieces, int numAllowedPieces)
    {
        // put your code here
        double excessCost =0.0;
        int excess=0;
        if(numPieces<=numAllowedPieces)
        {
            excessCost=0;
        }
        else
        {
            excess=numPieces-numAllowedPieces;
            excessCost=excess*35;
        }
        return excessCost;
    }
    
    public String getExcessLuggageCostByPassenger(String passportNumber)    
    {
        if(passportNumber==p.passportNumber)
        {
            String totalCost;
        }
        else
        {
            return "No Cost ";
        }
        return " ";
    }
    
    public String toString(){
        System.out.println("LUGGAGE MANIFEST: ");
        String details=addLuggage(p);
        return details;
    }
}

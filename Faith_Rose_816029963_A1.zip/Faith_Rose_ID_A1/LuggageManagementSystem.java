//816029963

import java.io.File;
import java.util.Scanner;
import java.time.LocalDateTime;
public class LuggageManagementSystem
{
    // instance variables - replace the example below with your own
    public static void main(String[] args){
        try
        {
            File tester = new File("testSampleFile.txt");
            Scanner scanner = new Scanner(tester);
            
            String testData = "";
            int i=0,count=0;
            String[] ppsNo=new String[3];
            String[] firstNames=new String[3];
            String[] lastNames=new String[3];
            String[] fsNo=new String[3];
            String[] destinations=new String[3];
            String[] origins=new String[3];
            Passenger p;
            int j=0;
            LocalDateTime d = LocalDateTime.of(2023, 1,23,10, 00, 00);
            
            while(scanner.hasNextLine())
            {
               testData = scanner.nextLine();
               String[] words =testData.split(" ");
               ppsNo[i]=words[0];
               firstNames[i]= words[1];
               lastNames[i]= words[2];
               fsNo[i]=words[3];
               destinations[i]=words[4];
               origins[i]=words[5];
               
               String detail=ppsNo[i]+firstNames[i]+lastNames[i]+fsNo[i]+destinations[i]+origins[i];
               System.out.println(detail);
               i++;

            }
            scanner.close();
            for(count=0;count<=i;count++)
            {
                p = new Passenger(ppsNo[count],firstNames[count],lastNames[count],fsNo[count]);
                Flight f = new Flight(fsNo[count],destinations[count],origins[count],d);
                System.out.println(p);
                System.out.println(f);
                LuggageManifest lm = new LuggageManifest();
                System.out.println(lm);
                LuggageSlip ls = new LuggageSlip(p,f);
                System.out.println(ls);

            }
        }
        catch (Exception e)
        {
            //System.out.println("Error");
        }

    }

}
